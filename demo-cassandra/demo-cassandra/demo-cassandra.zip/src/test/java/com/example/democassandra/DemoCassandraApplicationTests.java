package com.example.democassandra;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoCassandraApplicationTests {

	@Test
	void contextLoads() {
	}

}
